$(document).ready(function(){
    $('.contene2r').hide();
})

function cargador(){
    $('.contene2r').show();
}